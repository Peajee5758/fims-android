# FIMS Central Android - panduan build APK dari HP

Paket ini adalah proyek Android WebView yang membungkus frontend FIMS lokal (`app/src/main/assets/index.html`) menjadi aplikasi Android. APK belum dibangun di paket ini; GitHub Actions akan membangunnya di cloud.

## Cara build hanya dengan HP Android
1. Buat repository GitHub baru bernama `fims-android` (boleh public atau private).
2. Upload seluruh isi folder proyek ini ke root repository. Pastikan folder `.github/workflows` ikut terunggah.
3. Buka repository > tab **Actions** > workflow **Build FIMS Android APK**.
4. Tekan **Run workflow** bila build belum otomatis berjalan. Tunggu sampai status hijau.
5. Buka hasil run yang berhasil, gulir ke bagian **Artifacts**, lalu unduh `FIMS-Central-debug-APK`.
6. Ekstrak ZIP hasil unduhan, buka `app-debug.apk`, lalu izinkan pemasangan dari sumber tersebut bila Android meminta.

## Catatan
- Ini APK debug untuk uji coba, belum APK rilis bertanda tangan produksi.
- Data contoh disimpan lokal di perangkat/browser WebView. Belum tersambung ke backend PostgreSQL.
- Jangan gunakan data simulasi untuk transaksi operasional nyata.
- Untuk menghubungkan backend, perlu API HTTPS, autentikasi, serta sinkronisasi dan pengujian setiap modul.
