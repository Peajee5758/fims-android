# FIMS Central Android - Versi Uji Coba Lokal

Aplikasi Android menggunakan WebView dan halaman `app/src/main/assets/index.html`.

## Fitur uji coba
- Login demo dan hak akses berbasis jabatan.
- Peran: Super Admin, Manager, Supervisor, Operator, Purchasing, Sales, Finance, Auditor.
- Pembatasan menu berdasarkan peran dan lokasi.
- Master barang, supplier, customer, dan tangki.
- Penerimaan dan penyaluran dengan validasi stok serta kapasitas tangki.
- Dokumen PO, SO, DO, Invoice dengan status persetujuan.
- Rekonsiliasi fisik vs saldo buku, audit log, dan ekspor CSV.
- Penyimpanan data lokal menggunakan localStorage WebView.

## Akun demo
- admin / admin123
- manager / manager123
- supervisor / supervisor123
- operator / operator123
- purchasing / purchasing123
- sales / sales123
- finance / finance123
- auditor / auditor123

## Catatan penting
Versi ini untuk simulasi lokal, bukan sistem produksi. Data hanya tersimpan pada perangkat yang digunakan dan dapat hilang jika data aplikasi dibersihkan atau aplikasi dihapus. Password demo disimpan lokal dan bukan mekanisme keamanan produksi. Sebelum digunakan operasional, implementasikan autentikasi aman, otorisasi sisi server/API, database terpusat, audit yang tidak dapat diubah sembarang pengguna, backup, serta pengujian dan persetujuan prosedur operasional.
